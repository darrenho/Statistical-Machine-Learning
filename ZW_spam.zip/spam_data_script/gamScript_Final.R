#Additve and Generalized Additive models
library(gam)

#AMs
set.seed(2014)
##############################################
#AMs example 1
##############################################
n = 200
#Create set of covariates - x5 will be noise covariate
x1 = runif(n, 0, 1)
x2 = runif(n, 0, 1)
x3 = runif(n, 0, 1)
x4 = runif(n, 0, 1)
x5 = runif(n, 0, 1)
#Create synthetic 'y' values with error
y = sin(6*x1) + 3*x2^2 + (0.5*x3) + exp(-8*x4) + rnorm(n, 0, 0.5)
#true marginal effects
par(mfrow = c(2,2))
plot(x1, sin(6*x1))
plot(x2, 3*x2^2)
plot(x3, 0.5*x3)
plot(x4, exp(-8*x4))
#empirical marginal effects
par(mfrow = c(2,2))
plot(x1, y)
plot(x2, y)
plot(x3, y)
plot(x4, y)
#fit the model - can choose smoothness via CV
#smoothness is implicit in the "df =" argument
#"df" argument sets the value for trace(S_j(lambda_j))-1
#where S_j is the smoothing is the smoothing spline operator matrix
m1 = gam(y ~ s(x1, df = 3) + s(x2, df = 3) + s(x3, df = 3) + 
s(x4, df = 3)+s(x5, df = 3))
summary(m1)
#Coefficients represent the linear part of hat(f_j)
round( coefficients(summary.glm(m1)), 3)
m1$iter

#plot estimated marginal effects with std err
par(mfrow = c(3,2))
plot(m1, se = TRUE)
m1$df.resid
sqrt( sum(m1$resid^2) / m1$df.resid)
##############################################
#AMs example 2
##############################################
n = 200
#Create set of covariates - x5 and x6 will be noise covariates
x1 = runif(n, 0, 1)
x2 = runif(n, 0, 1)
x3 = runif(n, 0, 1)
x4 = sample(c(0,1), n, replace = T)
x5 = runif(n, 0, 1)
x6 = runif(n, 0, 1)
#Create synthetic 'y' values with noise
y = sin((2*x4 + 4)*x1) + 3*x2 - x3^3 + rnorm(n, 0, 0.5)
#true marginal effects
par(mfrow = c(2,2))
plot(x1, sin((2*x4 + 4)*x1), pch = 2*x4+1)
plot(x2, 3*x2,pch = 2*x4+1)
plot(x3, -1*x3^3, pch = 2*x4+1)
plot(x4, y,pch = 2*x4+1)
#empirical marginal effects
par(mfrow = c(2,2))
plot(x1, y,pch = 2*x4+1)
plot(x2, y, pch = 2*x4+1 )
plot(x3, y, pch = 2*x4+1)
plot(x4, y, pch = 2*x4+1 )
#fit the model - can choose smoothness via CV
#Can mix in interactions, linear, and non-linear parts
m2 = gam(y ~ s(x1, spar = 1) + s(x1, spar = 1):x4 + x2 + s(x3, df = 4) + x4 + s(x5, df = 4)+ s(x6, df = 4))
summary(m2)
round( coefficients(summary.glm(m2)), 3)
#plot estimated marginal effects with std err
par(mfrow = c(3,2))
plot(m2, se = TRUE)
m2$df.resid
sqrt( sum(m2$resid^2) / m2$df.resid)
##############################################
#GAMs
##############################################

#load spam data
#contains binary response on whether email was spam (= 1) or not (= 0)
#48 predictors on the % of words in email that match a given word
#e.g. "internet", "business", "money", "free", "george"
#6 predictors indicating the percentage of characters matching
#certain characters e.g "!", "$", "("
#3 predictors indicating avg/longest/sum length of uninterrupted capital letters

setwd("~/Dropbox/MachineLearning/Present2/spambase")
spamd = read.csv("spambase.data2", header = T)
vars = colnames(spamd)[1:58]
spamd2 = read.csv("spambase.data", header = F)
colnames(spamd2) = vars
spam = spamd2
#hist(spam$data)
X = spam[,1:57]
X = as.matrix(X)
Xtrans = log(X + 0.1)
Y = spam[,58]
Y = as.matrix(Y)

spamt = data.frame(cbind(Xtrans, Y))
colnames(spamt)[58] = "spam"
names(spamt)
n = dim(spamt)[1]
#Get a subset to use as training data
set.seed(2014)
sub = sample(1:n, 2000, replace = F)
#Fit the GAM model
spam.gam = gam(spam~ s(our) + s(remove) + s(internet) + s(free) + s(business) + s(money) + s(caprltot) + s(char_4) + s(char_5)
+ s(hp) + s(george)+ s(a1999) + s(re) + s(edu) , family= "binomial", data = spamt[sub,])
round( coefficients(summary.glm(spam.gam)), 3)
spam.gam$iter
par(mfrow = c(4,4))
plot(spam.gam, se = T)

preds.gam = predict(spam.gam, spamt[-sub,1:57], type = "response")
preds.gam = round(preds.gam)
Ytest = spamt[-sub,58]
#Error rate
length(which(preds.gam != Ytest)) / length(Ytest)

#compare to regular glm
spam.glm = glm(spam~our+remove+internet+free+business+money+
caprltot+char_4+char_5+hp+george+a1999+re+edu, family = "binomial", data = spamt[sub,])
summary(spam.glm)
preds.glm = predict(spam.glm, spamt[-sub,1:57], type = "response")
preds.glm = round(preds.glm)
Ytest = spamt[-sub,58]
#Error rate
length(which(preds.glm != Ytest)) / length(Ytest)

##############################################
#Sensitivity and specificity:
#In the spam data, it might be bad to
#classify an email as spam (1) when in fact
#it is not (i.e. commit a false positive). We can 
#examine the performance of our predictions in 
#terms of sensitivity and specificity via an ROC plot.
#Sensitivity: probability flagging, given email is spam
#Specificity: probability not flagging, given email is not spam
#In this example, we might want to sacrifice some sensitivity
#for a higher specificity. We can do this by increasing
#the threshold for a posterior probabilty needed to flag an
#email as spam.
##############################################

#Using the GAM model and test data from above...
preds = predict(spam.gam, spamt[-sub,1:57], type = "response")

#Use 0.50 as the cut value
preds.50 = round(preds)
Ytest = spamt[-sub,58]
ntest = length(Ytest)
#count types of errors
tp = length(which(preds.50 == 1 & Ytest == 1))
fp = length(which(preds.50 == 1 & Ytest == 0))
tn = length(which(preds.50 == 0 & Ytest == 0))
fn = length(which(preds.50 == 0 & Ytest == 1))
conf.mat.50 = rbind(c(tp,fp),c(fn,tn))
colnames(conf.mat.50) = c("T:spam", "T:not_spam")
rownames(conf.mat.50) = c("P:spam", "P:not_spam")
conf.mat.50
#compute statistics of interest
sens = tp/(tp+fn)
spec = tn/(tn+fp)
ppv = tp/(tp+fp)
npv = tn/(tn+fn)
accur = (tp+tn)/ntest
#sensitivity and specificity
sens
spec
#Positve and negative predictive values
#ppv
#npv
#overall error rate
1-accur

prob.cut = seq(0.05, 0.95, by = 0.05 )
k = length(prob.cut)
SENS = c()
SPEC = c()
for(i in 1:k)
{
	preds.p = (preds > prob.cut[i]) * 1
	tp = length(which(preds.p == 1 & Ytest == 1))
	fp = length(which(preds.p == 1 & Ytest == 0))
	tn = length(which(preds.p == 0 & Ytest == 0))
	fn = length(which(preds.p == 0 & Ytest == 1))
	sens = tp/(tp+fn)
	spec = tn/(tn+fp)
	SENS = c(SENS, sens)
	SPEC = c(SPEC, spec)
}
#Plot 1
plot(1-c(0, SPEC, 1), c(1, SENS, 0), type = "b", pch = 16,
xlab = "1 - Specificity", ylab = "Sensitivity", main = "ROC plot: email spam")
abline(0, 1, lty = 2)
points(0, 1, pch = "x", col = "red")
#Plot 2
plot(1-SPEC, SENS , xlab = "1 - Specificity", ylab = "Sensitivity",
main = "ROC plot: email spam")
#Plot 3
plot(1-SPEC, SENS,pch = NA,xlab = "1 - Specificity", ylab = "Sensitivity",
main = "ROC plot: email spam")
text(1-SPEC, SENS, labels = as.character(prob.cut), cex = 0.8)


#Suppose we choose 0.75 as the threshold
preds.75 = (preds > 0.75)*1
Ytest = spamt[-sub,58]
ntest = length(Ytest)
#count types of errors
tp = length(which(preds.75 == 1 & Ytest == 1))
fp = length(which(preds.75 == 1 & Ytest == 0))
tn = length(which(preds.75 == 0 & Ytest == 0))
fn = length(which(preds.75 == 0 & Ytest == 1))
conf.mat.75 = rbind(c(tp,fp),c(fn,tn))
colnames(conf.mat.75) = c("T:spam", "T:not_spam")
rownames(conf.mat.75) = c("P:spam", "P:not_spam")
conf.mat.75
#compute statistics of interest
sens = tp/(tp+fn)
spec = tn/(tn+fp)
#ppv = tp/(tp+fp)
#npv = tn/(tn+fn)
accur = (tp+tn)/ntest
#sensitivity and specificity
sens
spec
#Positve and negative predictive values
#ppv
#npv
#overall error rate
1-accur



