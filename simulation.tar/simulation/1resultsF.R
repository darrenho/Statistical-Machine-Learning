resultsF = function(input,thresh,parallelDir){
	source(paste(c(parallelDir,'1utilityFunctions.R'),collapse=''))
	source(paste(c(parallelDir,'1directoriesParameters.R'),collapse=''))

	n         = input$n
	p         = input$p
	rho       = input$rho
	alpha     = input$alpha
	snr       = input$snr
	noiseType = as.vector(input$noiseType)
	
	nChar       = as.character(n)
	pChar       = as.character(p)	
	alphaChar   = as.character(format(alpha,scientific=T))
	snrChar     = as.character(format(snr,scientific=T))
	rhoChar     = as.character(format(rho,scientific=T))		
	
  results = list()
  results$Ytest      = matrix(0,nrow=nTest,ncol=B)
  results$Y          = matrix(0,nrow=n,ncol=B)
  results$sigmaHat   = rep(0,B)
  results$C_star     = rep(0,B)
    	
	results$predRisk = list()
	
  #GCV
    results$beta.gcv  	   = matrix(0,nrow=p,ncol=B)
    results$Yhat.gcv  	   = matrix(0,nrow=nTest,ncol=B)
    results$predRisk$gcv   = rep(0,B)    
	#CV
    results$beta.cv  	  = matrix(0,nrow=p,ncol=B)
    results$Yhat.cv       = matrix(0,nrow=nTest,ncol=B)
    results$predRisk$cv   = rep(0,B)    
	#AIC
    results$beta.aic       = matrix(0,nrow=p,ncol=B)
    results$Yhat.aic 	     = matrix(0,nrow=nTest,ncol=B)
    results$predRisk$aic   = rep(0,B)    
    results$lambdaGrid.aic = vector('list',length=B)
    results$infoScore.aic  = vector('list',length=B)
	#AIC, variance unknown
    results$beta.aicVar       = matrix(0,nrow=p,ncol=B)
    results$Yhat.aicVar       = matrix(0,nrow=nTest,ncol=B)
    results$predRisk$aicVar   = rep(0,B)    
    results$lambdaGrid.aicVar = vector('list',length=B)
    results$infoScore.aicVar  = vector('list',length=B)
	#BIC
    results$beta.bic       = matrix(0,nrow=p,ncol=B)
    results$Yhat.bic       = matrix(0,nrow=nTest,ncol=B)
    results$predRisk$bic   = rep(0,B)    
    results$lambdaGrid.bic = vector('list',length=B)
    results$infoScore.bic  = vector('list',length=B)
	#BIC, variance unknown
    results$beta.bicVar       = matrix(0,nrow=p,ncol=B)
    results$Yhat.bicVar       = matrix(0,nrow=nTest,ncol=B)
    results$predRisk$bicVar   = rep(0,B)    
    results$lambdaGrid.bicVar = vector('list',length=B)
    results$infoScore.bicVar  = vector('list',length=B)
  #CCV
	  results$beta.ccv       = matrix(0,nrow=p,ncol=B)
	  results$Yhat.ccv       = matrix(0,nrow=nTest,ncol=B)
	  results$predRisk$ccv   = rep(0,B)    

	#SSR
	  results$beta.ssr       = matrix(0,nrow=p,ncol=B)
	  results$Yhat.ssr       = matrix(0,nrow=nTest,ncol=B)
	  results$predRisk$ssr   = rep(0,B)    
	
	cov.matrix       = matrix(rho,nrow=p,ncol=p)
	diag(cov.matrix) = 1
	cov.matrix.sqrt  = chol(cov.matrix)
	cat(paste('##### n=',n,' p= ',p,'\n'))
	
	require(VGAM)
	for(b in 1:B){
		if(b %% round(B/4) == 0){
	    	cat(paste(b,'\n'))
			progress = paste( c('n',nChar,'p',pChar,'alpha',alphaChar,
			                    'snr',snrChar,'rho',rhoChar,
			                    '_b_',as.character(b),'\n'),collapse='')
			printToFileF(paste(c(objectsDir,'_progress.txt'),collapse=''),
	                     progress)
		}
		beta_0      = rep(0,p)
		s           = ceiling(n^alpha)
		beta_0[1:s] = rlaplace(s)
	  snr.orig    = t(beta_0) %*% cov.matrix %*% beta_0/(sigma**2)
	  beta_0      = beta_0*sqrt(snr/snr.orig)

    X           = matrix(rnorm(p*n),nrow=n,ncol=p) %*% cov.matrix.sqrt
		Xtest       = matrix(rnorm(p*nTest),nrow=nTest,ncol=p) %*% cov.matrix.sqrt
		
#	    X           = scale(X)  
#		X_bar       = attributes(X)$"scaled:center"
#		X_std       = attributes(X)$"scaled:scale"
#		Xtest       = t((t(Xtest) - X_bar)/X_std)

    mu          = X%*%beta_0
		muTest      = Xtest %*% beta_0	    
	    
    if(noiseType == 'Student'){
      Y                   = mu + sigma*sqrt((nu-2)/nu)*rt(n,nu,0)
      Ytest               = Xtest %*% beta_0 + sigma*sqrt((nu-2)/nu)*rt(nTest,nu,0)
    }
    if(noiseType == 'Gaussian'){
      Y                   = mu + sigma*rnorm(n)
      Ytest               = Xtest %*% beta_0 + sigma*rnorm(nTest)
    }
    results$Y[,b]     = Y
    results$Ytest[,b] = Ytest
        
	  ########################################################
	  ########################################################
	  ############## Results
	  ########################################################
	  ########################################################
	  source(paste(c(tuneParmSelDir,'2infoMainLars.R'),collapse = ''))
	  source(paste(c(tuneParmSelDir,'2crossValidationLars.R'),collapse = ''))
    source(paste(c(tuneParmSelDir,'2scaledSparseLars.R'),collapse = ''))

    #CV
    out = cv.lambdaF(X,Y,Xtest,Ytest,beta_0,
                     parallelDir,objectsDir,thresh)
    results$beta.cv[,b]     = out$beta
    results$Yhat.cv[,b]     = out$Yhat
	  results$predRisk$cv[b]  = out$predRisk

    #CCV
    out = ccvF(X,Y,Xtest,Ytest,beta_0,
               parallelDir,objectsDir,thresh)
    results$beta.ccv[,b]     = out$beta
    results$Yhat.ccv[,b]     = out$Yhat
    results$predRisk$ccv[b]  = out$predRisk
  
    #SSR
    out = ssrF(X,Y,Xtest,Ytest,beta_0,parallelDir,objectsDir)            
    results$beta.ssr[,b]     = out$beta
    results$Yhat.ssr[,b]     = out$Yhat
    results$predRisk$ssr[b]  = out$predRisk

    #GCV
    out = infoMainF(X = X,Y = Y,Xtest = Xtest,Ytest = Ytest,
                        beta_0 = beta_0, mu = mu, muTest = muTest,
                        infoType='GCV',varianceKnown=TRUE,MA=FALSE,
                        parallelDir=parallelDir,objectsDir = objectsDir,
                        thresh = thresh)
    results$beta.gcv[,b]     = out$beta
    results$Yhat.gcv[,b]     = out$Yhat

	  results$predRisk$gcv[b]  = out$predRisk
	    		    
    #AIC
    out = infoMainF(X = X,Y = Y,Xtest = Xtest,Ytest = Ytest,
                        beta_0 = beta_0, mu = mu, muTest = muTest,
                        infoType='AIC',varianceKnown=TRUE,MA=FALSE,
                        parallelDir=parallelDir,objectsDir = objectsDir,
                        thresh = thresh)
    results$beta.aic[,b]        = out$beta
    results$Yhat.aic[,b]        = out$Yhat
    results$infoScore.aic[[b]]  = out$infoScore
    results$predRisk$aic[b]                 = out$predRisk

    #AIC unknown variance
    out = infoMainF(X = X,Y = Y,Xtest = Xtest,Ytest = Ytest,
                        beta_0 = beta_0, mu = mu, muTest = muTest,
                        infoType='AIC',varianceKnown=FALSE,MA=FALSE,
                        parallelDir=parallelDir,objectsDir = objectsDir,
                        thresh = thresh)
    results$beta.aicVar[,b]        = out$beta
    results$Yhat.aicVar[,b]        = out$Yhat
    results$infoScore.aicVar[[b]]  = out$infoScore
    results$predRisk$aicVar[b]                 = out$predRisk
    results$sigmaHat[b]                        = out$sigmaHat        

    #BIC
    out = infoMainF(X = X,Y = Y,Xtest = Xtest,Ytest = Ytest,
                        beta_0 = beta_0, mu = mu, muTest = muTest,
                        infoType='BIC',varianceKnown=TRUE,MA=FALSE,
                        parallelDir=parallelDir,objectsDir = objectsDir,
                        thresh = thresh)

    results$beta.bic[,b]       = out$beta
    results$Yhat.bic[,b]       = out$Yhat
  	results$infoScore.bic[[b]] = out$infoScore
    results$predRisk$bic[b]    = out$predRisk
    
    #BIC unknown variance
    out = infoMainF(X = X,Y = Y,Xtest = Xtest,Ytest = Ytest,
                        beta_0 = beta_0, mu = mu, muTest = muTest,
                        infoType='BIC',varianceKnown=FALSE,MA=FALSE,
                        parallelDir=parallelDir,objectsDir = objectsDir,
                        thresh = thresh)

    results$beta.bicVar[,b]        = out$beta
    results$Yhat.bicVar[,b]        = out$Yhat
  	results$infoScore.bicVar[[b]]  = out$infoScore

	  results$predRisk$bicVar[b]                 = out$predRisk
	}    
	save(results,file=paste(c(objectsDir,'n',nChar,'p',pChar,'NoiseType',noiseType,'Alpha',alphaChar,
	                          'Snr',snrChar,'Rho',rhoChar,'.Rdata'),collapse=''))
}