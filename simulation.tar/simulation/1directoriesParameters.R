#Specify these objects to a directory tree. 

tuneParmSelDir = '.../simulation/'
objectsDir     = '.../simulation/objects/'
parallelDir    = '.../simulation/'
figuresDir     = '.../simulation/figures/'

nList = c(100)         #Note: for CCV, n must balance with K=10 fold CV
pList = c(75,350,1000)

##################
# Different simulation conditions.  
##################
rhoList       = c(0.2,0.5,0.95)
alphaList     = c(0.1,0.33,0.5) #NOTE!!!!!!!!! 100^0.9 > 63 > 50 = p_min
snrList       = c(0.5,5.0,10.0)
noiseTypeGrid = c('Gaussian')#,'Student')

B             = 100 #replications

thresh         = 1e-7

sigma          = 1
nTest          = 50
nu             = 3