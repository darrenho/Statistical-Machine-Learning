plotF = function(listForApply,ylim,selectedMethods = 1:7,savePlot = T){
	#par(mfrow=c(mfrow1,mfrow2),cex.main=.4,cex.axis=.3,mar=rep(1.3,4))
	for(input in listForApply){
		n         = input$n
		p         = input$p
		rho       = input$rho
		alpha     = input$alpha
		snr       = input$snr
		noiseType = as.vector(input$noiseType)
				
		nChar       = as.character(n)
		pChar       = as.character(p)	
		alphaChar   = as.character(format(alpha,scientific=T))
		snrChar     = as.character(format(snr,scientific=T))
		rhoChar     = as.character(format(rho,scientific=T))		
		
		load(file=paste(c(objectsDir,'n',nChar,'p',pChar,
			              'NoiseType',noiseType,'Alpha',alphaChar,
			              'Snr',snrChar,'Rho',rhoChar,'.Rdata'),collapse=''))
		#This stupid bullshit is because scientific in R leaves decimals, which 
		#latex won't recognize for figures    
		if(alpha == 0.33){
		  alphaChar   = '33e-02'
		}
		if(rho == 0.95){
		  rhoChar   = '95e-02'
		}
		
		if(savePlot){
		  figName = paste(c(figuresDir,'n',nChar,'p',pChar,
		                    'NoiseType',noiseType,'Alpha',alphaChar,
		                    'Snr',snrChar,'Rho',rhoChar,'.pdf'),collapse='')		  
		  pdf(figName)
		}		
		
    methodNames = c('GCV','CV','AIC','AICv','BIC','BICv','CCV')
		#boxplot(results$predRisk[select],main=simCond,las=2,ylim=ylim,cex=.5)
		violins(results$predRisk[selectedMethods],drawRect=T,connect='mean',ylim=ylim,names=methodNames[selectedMethods],
		        CImed=F,deciles=F,quantiles=.5,pchMed=17,rectCol='transparent')    						
	  if(savePlot){	
		  dev.off()
	  }		
	}
}
