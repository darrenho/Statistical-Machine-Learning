cv.lambdaF = function(X,Y,Xtest,Ytest,beta_0,
                      parallelDir,objectsDir,thresh){
	source(paste(c(parallelDir,'1utilityFunctions.R'),collapse=''))
#		print('cv')	 
	require(glmnet)       		
	p          = ncol(X)
	n          = nrow(X)
	nTest      = nrow(Xtest)
	out.glmnet     = cv.glmnet(x=as.matrix(X),y=Y,alpha=1,intercept=FALSE,thresh=thresh)
	noConverge = TRUE
	maxIter    = 6
	sweep_lambda = 0
	while(noConverge){
		sweep_lambda = sweep_lambda + 1
		if(which.min(out.glmnet$cvm) == 1){ 
			printToFileF(paste(c(objectsDir,'boundaryCV','_n_',as.character(n),
		    	                 '_p_',as.character(p),'.txt'),collapse=''),
		         		 paste(c('upper '),collapse=''))            
		    break
		}		
		if(which.min(out.glmnet$cvm) == length(out.glmnet$cvm)){	
			lambdaGrid    = out.glmnet$lambda
			nLambda       = length(lambdaGrid)
			lambdaGridNew = exp(seq(log(lambdaGrid[nLambda]),
			                        log(lambdaGrid[nLambda]*.001),length=100))
			out.glmnet        = cv.glmnet(x=as.matrix(X),y=Y,alpha=1,thresh=thresh,
			                          intercept=FALSE,lambda=lambdaGridNew)	 
		} else {noConverge = FALSE}
		if(sweep_lambda == maxIter){ noConverge = FALSE }
	}	
	if(which.min(out.glmnet$cvm) == length(out.glmnet$cvm)){	
		printToFileF(paste(c(objectsDir,'boundaryCV','_n_',as.character(n),
			                 '_p_',as.character(p),'.txt'),collapse=''),
					 paste(c('lower '),collapse=''))
	}				 
	lambda.hat     = out.glmnet$lambda[which.min(out.glmnet$cvm)]
	beta.hat       = out.glmnet$glmnet.fit$beta[,which.min(out.glmnet$cvm)]
	return.list = list()
	Yhat = predict(out.glmnet,as.matrix(Xtest),s=lambda.hat)
	Yhat.oracle = Xtest %*% beta_0
	return.list[['predRisk']] = vecNormF(Ytest - Yhat,pNorm = 2,toPower = F)/
		                            vecNormF(Ytest - Yhat.oracle,pNorm = 2,toPower = F)
	return.list[['Yhat']]     = Yhat
	return.list[['beta']]       = beta.hat
	return.list[['lambda']]     = lambda.hat
	return(return.list)
}