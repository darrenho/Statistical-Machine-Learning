vecNormF = function(x,pNorm,toPower=FALSE){
	exponent = 1
	if(toPower){
		exponent = pNorm
	}
    return( (sum( x^pNorm ))**(1/exponent) )
}          	

printToFileF = function(fileName,textToSave){
	fileNameObject = file(fileName,'at')
	cat(textToSave,file=fileNameObject)
	close(fileNameObject)
}

forEachModelFunc = function(X,Y,n,validationSets,model){
  allObs = 1:n
  sweep = 1
  CV = rep(0,length(validationSets))
  for(i in validationSets){
    train  = allObs[-i]
    if(length(model) > 0){
      Xtrain.cv = data.frame(as.matrix(X[train,model],nrow= length(train),ncol=sum(model)))
      Xtest.cv  = data.frame(as.matrix(X[i,model],nrow=length(i),ncol=sum(model)))
      names(Xtrain.cv) = as.character(model)
      names(Xtest.cv)  = as.character(model)
      out              = lm(Y[train]~.,data=data.frame(Xtrain.cv))
      yHat             = predict(out,data.frame(Xtest.cv))
    }else(yHat = rep(mean(Y[i]),length(i)))    
    CVi              = mean((yHat - Y[i])^2)    
    CV[sweep]        = CVi
  }
  return(mean(CV))
}
