cv.lambdaF = function(X,Y,Xtest,Ytest,beta_0,
                      parallelDir,objectsDir,thresh){
	source(paste(c(parallelDir,'1utilityFunctions.R'),collapse=''))
	require(lars)       		
	p           = ncol(X)
	n           = nrow(X)
	nTest       = nrow(Xtest)
	out.lars    = lars(x=X,y=Y,type='lasso',trace=F,intercept=T,normalize=T,use.Gram=F)
	Y.hat       = predict(out.lars,X,type='fit',mode='fraction')
	beta.hat    = predict(out.lars,X,type='coef',mode='fraction')
	index       = Y.hat$fraction
	
	out.lars.cv = cv.lars(x=X,y=Y,K=10,trace=F,plot.it=F,se=FALSE,type='lasso',index=index,
	                      mode='fraction',normalize=T,intercept=T,use.Gram=F)
	index.min   = index[which.min(out.lars.cv$cv)] 

	Y.hat       = Y.hat$fit[,which.min(out.lars.cv$cv)]
	beta.hat    = beta.hat$coef[which.min(out.lars.cv$cv),]

	return.list = list()
#	if(predRiskFlag){
		Y.hat       = predict(out.lars,Xtest,s=index.min,type='fit',mode='fraction')$fit
		Yhat.oracle = Xtest %*% beta_0
		return.list[['predRisk']] = vecNormF(Ytest - Y.hat,pNorm = 2,toPower = F)/
		                            vecNormF(Ytest - Yhat.oracle,pNorm = 2,toPower = F)
		return.list[['Yhat']]     = Y.hat
	return.list[['beta']]       = beta.hat
	return(return.list)
}

ccvF = function(X,Y,Xtest,Ytest,beta_0,parallelDir,objectsDir,thresh){
  source(paste(c(parallelDir,'1utilityFunctions.R'),collapse=''))
  require(lars)
  p            = ncol(X)
  n            = nrow(X)
  nTest        = nrow(Xtest)
  out.lars     = lars(x=X,y=Y,type='lasso',trace=F,intercept=T,normalize=T,use.Gram=F)
  activeSets_0 = apply(abs(out.lars$beta),1,function(x){which(x>1e-16)})
  
  K = 10
  kFold          = sample(1:n)
  validationSets = vector('list',K)
  for(k in 1:K){
    validationSets[[k]] = kFold[((k-1)*(K)+1):(k*K)]  
  }
  
  #Need to only keep active sets with size n - n/K (due to CV)
  activeSets = list()
  sweep = 0 
  for(activeSet in activeSets_0){
    sweep = sweep + 1
    if(length(activeSet) < n - n/K){
      activeSets[[sweep]] = activeSet
    }
  }
  CVresults = rep(0,length(activeSets))
  sweep = 0
  
  for(activeSet in activeSets){
    sweep            = sweep + 1
    CVresults[sweep] = forEachModelFunc(X,Y,n,validationSets,activeSet)
  }  
  model.min = activeSets[[which.min(CVresults)]]
  if(length(model.min)==0){
    Y.hat    = rep(mean(Y),nTest)
    beta.hat = rep(0,p)
  }else{
    Xtrain.cv = data.frame(X[,model.min])
    Xtest.cv  = data.frame(Xtest[,model.min])    
    names(Xtrain.cv) = as.character(model.min)
    names(Xtest.cv)  = as.character(model.min)
    out                 = lm(Y~.,data=Xtrain.cv)    
    Y.hat               = predict(out,Xtest.cv)
    beta.hat            = rep(0,p)
    beta.hat[model.min] = coef(out)[-1]
  }
  return.list = list()
  Yhat.oracle = Xtest %*% beta_0
  return.list[['predRisk']] = vecNormF(Ytest - Y.hat,pNorm = 2,toPower = F)/
    vecNormF(Ytest - Yhat.oracle,pNorm = 2,toPower = F)
  return.list[['Yhat']]     = Y.hat
  return.list[['beta']]       = beta.hat
  return(return.list)
}