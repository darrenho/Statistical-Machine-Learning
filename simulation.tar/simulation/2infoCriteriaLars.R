sigmaHatCVF = function(X,Y){
	n             = length(Y)

	out.lars     = lars(x=X,y=Y,type='lasso',trace=F,intercept=T,normalize=T,use.Gram=F)
	Y.hat        = predict(out.lars,X,type='fit',mode='fraction')
	index        = Y.hat$fraction
	
	out.lars.cv  = cv.lars(x=X,y=Y,K=10,trace=F,plot.it=F,se=FALSE,type='lasso',index=index,
	                      mode='fraction',normalize=T,intercept=T,use.Gram=F)
	index.min    = index[which.min(out.lars.cv$cv)] 


#	Y.hat        = predict(out.lars,X,s=index.min,type='fit',mode='fraction')$fit
	Y.hat        = Y.hat$fit[,which.min(out.lars.cv$cv)]
	dfHat        = out.lars$df[which.min(out.lars.cv$cv)]
	
	difference    = Y.hat - as.vector(Y)
	trainingError = vecNormF(difference,pNorm = 2,toPower = FALSE)
	sigmaHat      = sqrt(1/(n - dfHat)*trainingError)
	return(sigmaHat)
}

infoCriteriaF = function(X,Y,mu,out.lars,infoType,varianceKnown){
	n             = nrow(X)
	Y.hat         = predict(out.lars,X,type='fit',mode='fraction')$fit
	dfHat         = out.lars$df

	difference    = Y.hat - as.vector(Y) #for conformable array
	trainingError = apply(difference,2,vecNormF,2,FALSE)
	return.list = list()	
	if(varianceKnown == FALSE){
		sigmaHat  = sigmaHatCVF(X,Y)
	}
	if(varianceKnown == TRUE){
#		sigmaHat  = sigma
	    sigmaHat  = vecNormF((Y - mu),pNorm = 2,toPower = TRUE)/sqrt(n)
	}
	if(infoType == 'GCV'){
		infoScore = trainingError/(1-dfHat/n)
	}	
	if(infoType == 'AIC'){
		infoScore = trainingError + 2*dfHat*sigmaHat**2		
	}
	if(infoType == 'BIC'){
		infoScore = trainingError + log(n)*dfHat*sigmaHat**2
	}
	if(infoType == 'optimalIC'){
		Cgrid = (1:100)/10
		infoScoreMat = matrix(0,nrow=100,ncol=length(dfHat))
		sweep = 0
		for(C in Cgrid){
			sweep = sweep + 1
			infoScoreMat[sweep,]= trainingError + C*dfHat*sigmaHat**2
		}
		lambda_C = apply(infoScoreMat,1,which.min)
		C_star = Cgrid[which.min(abs(lambda_C - lambda_star))]
		return.list$C_star = C_star
	}
	return.list$infoScore = infoScore
	return.list$sigmaHat  = sigmaHat
	return(return.list)
}
