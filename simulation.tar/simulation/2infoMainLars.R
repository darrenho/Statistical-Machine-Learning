infoMainF = function(X,Y,Xtest,Ytest,beta_0,mu,muTest,
                     infoType,varianceKnown,MA,
                     parallelDir,objectsDir,thresh,ourProp=FALSE){
	source(paste(c(parallelDir,'1utilityFunctions.R'),collapse=''))
#	source(paste(c(parallelDir,'1directoriesParameters.R'),collapse=''))	
	source(paste(c(parallelDir,'2infoCriteriaLars.R'),collapse=''))	
	require(lars)

	p     = length(beta_0)
	n     = length(mu)
	nTest = nrow(Xtest)

	out.lars    = lars(x=as.matrix(X),y=Y,type='lasso',trace=F,intercept=T,normalize=T,use.Gram=F)
	
	infoScore.out = infoCriteriaF(X,Y,mu,out.lars,infoType,varianceKnown)
	infoScore     = infoScore.out$infoScore
	lambdaGrid    = c(1e10,out.lars$lambda)
	lambda.min    = lambdaGrid[which.min(infoScore)]
	beta.hat      = predict(out.lars,X,s=lambda.min,type='coef',mode='lambda')$coef
	if(MA == TRUE){
		info.min = min(infoScore)
		delta    = infoScore - info.min
		weight   = exp(-1/2*delta)/(sum(exp(-1/2*delta)))	
		beta.hat = coef(out.lars)
		beta.hat = drop(t(beta.hat) %*% weight)
#		lambda.hat = c(out.lars$lambda %*% weight)
	}
	if(length(ourProp) > 1){
		beta.hat.old = beta.hat
		beta.hat     = rep(0,p)
		beta.hat[ourProp] = beta.hat.old
	}
	return.list = list()
	return.list[['beta']]       = beta.hat
#	return.list[['lambda']]     = lambda.hat
#	return.list[['lambdaGrid']]	= lambdaGrid
	return.list[['infoScore']]	= infoScore
	return.list[['sigmaHat']]   = infoScore.out$sigmaHat

	#if(predRiskFlag){
		Y.hat       = predict(out.lars,Xtest,s=lambda.min,type='fit',mode='lambda')$fit
		Yhat.oracle = muTest
		return.list[['predRisk']] = vecNormF(Ytest - Y.hat,pNorm = 2,toPower = F)/
		                            vecNormF(Ytest - Yhat.oracle,pNorm = 2,toPower = F)
		return.list[['Yhat']]     = Y.hat
	#if(getCorrectFeaturesFlag){#Type I    | hat{S} \cap S_0 | / |hat{S}|
		nonZeroBeta    = abs(beta_0) > 0
		nonZeroBetaHat = abs(beta.hat) > 0
		return.list[['precision']] = 
		            sum(nonZeroBetaHat[which(nonZeroBeta == TRUE)])/
		            sum(nonZeroBetaHat == TRUE) 
	#if(includeIncorrectFeaturesFlag){#Type II    | hat{S} \cap S_0 | / |S_0|
		nonZeroBeta    = abs(beta_0) > 0
		nonZeroBetaHat = abs(beta.hat) > 0
		return.list[['recall']] = 
		            sum(nonZeroBetaHat[which(nonZeroBeta == TRUE)])/
		            sum(nonZeroBeta == TRUE) 
	#if(consistentFlag){
		return.list[['consistent']] = vecNormF(beta_0-beta.hat,pNorm = 2,toPower = TRUE)/
		                              vecNormF(beta_0,pNorm = 2,toPower = TRUE)
	return(return.list)
}