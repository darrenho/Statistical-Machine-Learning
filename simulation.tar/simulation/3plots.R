source('1directoriesParameters.R')
require(caroline)
source('3plotsF.R')
apply.list = expand.grid(nList,pList,rhoList,alphaList,snrList,noiseTypeGrid)
names(apply.list) = c('n','p','rho','alpha','snr','noiseType')
listForApply = vector('list',length=nrow(apply.list))
for(i in 1:nrow(apply.list)){
  listForApply[[i]] = apply.list[i,]
}




load(file='/Users/darrenho/Dropbox/research/papers/Lasso/JMLR/simulation/objects/n100p101NoiseTypeGaussianAlpha1e-01Snr5e-01Rho2e-01.Rdata')
ylim = c(.9,3.5)
violins(results$predRisk,drawRect=T,connect='mean',ylim=ylim,
        CImed=F,deciles=F,quantiles=.5,pchMed=17,rectCol='transparent')  					

waitingForRunToFinish = F
if(waitingForRunToFinish){
  rhoList       = c(0.2,0.5,0.95)
  alphaList     = c(0.1,0.33,0.5)
  snrList       = c(0.5)
  noiseTypeGrid = c('Gaussian')
  apply.list = expand.grid(nList,pList,rhoList,alphaList,snrList,noiseTypeGrid)
  names(apply.list) = c('n','p','rho','alpha','snr','noiseType')
  listForApply_0 = vector('list',length=nrow(apply.list))
  for(i in 1:nrow(apply.list)){
    listForApply_0[[i]] = apply.list[i,]
  }
  plotF(listForApply_0,c(.9,2.5))
}

plotF(listForApply,c(.95,3.5),selectedMethods = c(1,2,3,5,7))

