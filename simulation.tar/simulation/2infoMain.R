infoMainF = function(X,Y,Xtest,Ytest,beta_0,mu,muTest,
                     infoType,varianceKnown,MA,
                     parallelDir,objectsDir,thresh,ourProp=FALSE){
	source(paste(c(parallelDir,'1utilityFunctions.R'),collapse=''))
	source(paste(c(parallelDir,'1directoriesParameters.R'),collapse=''))	
	source(paste(c(parallelDir,'2infoCriteria.R'),collapse=''))	
	require(glmnet)

	p     = length(beta_0)
	n     = length(mu)
	nTest = nrow(Xtest)

	out.glmnet    = glmnet(x=as.matrix(X),y=Y,alpha=1,
                          intercept=FALSE,thresh=thresh)        
	lambdaGrid    = out.glmnet$lambda                          
	infoScore.out = infoCriteriaF(X,Y,mu,out.glmnet,infoType,varianceKnown,thresh)
	infoScore     = infoScore.out$infoScore

	noConverge    = TRUE
	maxIter       = 6
	sweep_lambda  = 0
	while(noConverge){
		sweep_lambda = sweep_lambda + 1
		if(which.min(infoScore) == 1){ 
			printToFileF(paste(c(objectsDir,'boundary',infoType,
			                     '_n_',as.character(n),'_p_',as.character(p),
			                     '.txt'),collapse=''),
						 paste(c('upper '),collapse=''))            
			break
			noConverge = FALSE #this means we have beta = 0
		}
		if(which.min(infoScore) == length(infoScore)){
#				print('before')
			lambdaGrid    = out.glmnet$lambda
			nLambda       = length(lambdaGrid)
			lambdaGrid    = exp(seq(log(lambdaGrid[nLambda]),
			                        log(lambdaGrid[nLambda]*.001),length=nLambda))
#			print('after')												                        
			out.glmnet    = glmnet(x=as.matrix(X),y=Y,alpha=1,
			                       intercept=FALSE,lambda=lambdaGrid,thresh=thresh)	 
#		print('afterafter')
			infoScore.out = infoCriteriaF(X,Y,mu,out.glmnet,infoType,varianceKnown,thresh)
			infoScore     = infoScore.out$infoScore

		} else {noConverge = FALSE}
		if(sweep_lambda == maxIter){ noConverge = FALSE }
	}
	if(which.min(infoScore) == length(infoScore)){	
		printToFileF(paste(c(objectsDir,'boundary',infoType,'_n_',as.character(n),
			                 '_p_',as.character(p),'.txt'),collapse=''),
					 paste(c('lower '),collapse=''))
	}
	lambda.hat  = out.glmnet$lambda[which.min(infoScore)]
	beta.hat    = out.glmnet$beta[,which.min(infoScore)]
	if(MA == TRUE){
		info.min = min(infoScore)
		delta    = infoScore - info.min
		weight   = exp(-1/2*delta)/(sum(exp(-1/2*delta)))	
		beta.hat  = as.vector(out.glmnet$beta %*% weight)
		lambda.hat = c(out.glmnet$lambda %*% weight)
	}
	if(length(ourProp) > 1){
		beta.hat.old = beta.hat
		beta.hat     = rep(0,p)
		beta.hat[ourProp] = beta.hat.old
	}
	return.list = list()
	return.list[['beta']]       = beta.hat
	return.list[['lambda']]     = lambda.hat
	return.list[['lambdaGrid']]	= lambdaGrid
	return.list[['infoScore']]	= infoScore
	return.list[['sigmaHat']]   = infoScore.out$sigmaHat

	#if(predRiskFlag){
		Yhat = predict(out.glmnet,as.matrix(Xtest),s=lambda.hat)
		Yhat.oracle = muTest
		return.list[['predRisk']] = vecNormF(Ytest - Yhat,pNorm = 2,toPower = F)/
		                            vecNormF(Ytest - Yhat.oracle,pNorm = 2,toPower = F)
		return.list[['Yhat']]     = Yhat
	#if(getCorrectFeaturesFlag){#Type I    | hat{S} \cap S_0 | / |hat{S}|
		nonZeroBeta    = abs(beta_0) > 0
		nonZeroBetaHat = abs(beta.hat) > 0
		return.list[['precision']] = 
		            sum(nonZeroBetaHat[which(nonZeroBeta == TRUE)])/
		            sum(nonZeroBetaHat == TRUE) 
	#if(includeIncorrectFeaturesFlag){#Type II    | hat{S} \cap S_0 | / |S_0|
		nonZeroBeta    = abs(beta_0) > 0
		nonZeroBetaHat = abs(beta.hat) > 0
		return.list[['recall']] = 
		            sum(nonZeroBetaHat[which(nonZeroBeta == TRUE)])/
		            sum(nonZeroBeta == TRUE) 
	#if(consistentFlag){
		return.list[['consistent']] = vecNormF(beta_0-beta.hat,pNorm = 2,toPower = TRUE)/
		                              vecNormF(beta_0,pNorm = 2,toPower = TRUE)
	return(return.list)
}