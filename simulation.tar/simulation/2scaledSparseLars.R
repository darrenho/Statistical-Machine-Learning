ssrF = function(X,Y,Xtest,Ytest,beta_0,parallelDir,objectsDir){
  source(paste(c(parallelDir,'1utilityFunctions.R'),collapse=''))
  require(scalreg)  
  p          = ncol(X)
  n          = nrow(X)
  nTest      = nrow(Xtest)
  out.ssr    = scalreg(X=X,y=Y)
  Y.hat      = predict(out.ssr,Xtest)
  beta.hat   = out.ssr$coefficients
  
  return.list = list()
  Yhat.oracle = Xtest %*% beta_0
  return.list[['predRisk']] = vecNormF(Ytest - Y.hat,pNorm = 2,toPower = F)/
    vecNormF(Ytest - Yhat.oracle,pNorm = 2,toPower = F)
  return.list[['Yhat']]     = Y.hat
  return.list[['beta']]     = beta.hat
  return(return.list)
}