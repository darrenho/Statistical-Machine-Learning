Set the simulation parameters with 1directoriesParameters.R (as an aside, it 
takes the better part of a day to run the current parameter settings)

The function call is contained in _mainFile.R, which will parallelize over
cores of your processor.

The workhorse function is 1resultsF.R, which creates all the simulation objects
and calls the various methods.

The "Main" versus "Lars" is for using glmnet versus lars for producing the
lasso fit (glmnet struggles in various circumstances)

The 3plots.R produces plots for all the simulation conditions outlined in
1directoriesParameters.R by calling the function in 3plotsF.R

