source('1utilityFunctions.R')
source('1directoriesParameters.R')

apply.list = expand.grid(nList,pList,rhoList,alphaList,snrList,noiseTypeGrid)
names(apply.list) = c('n','p','rho','alpha','snr','noiseType')
listForApply = vector('list',length=nrow(apply.list))
for(i in 1:nrow(apply.list)){
	listForApply[[i]] = apply.list[i,]
}

source(paste(c(parallelDir,'1resultsF.R'),collapse=''))
#output = resultsF(listForApply[[2]],thresh,parallelDir) #For Testing

library(snowfall)
sfInit(restore = TRUE,parallel=TRUE, cpus=4, type="SOCK")
sfClusterApplyLB(listForApply,resultsF,thresh,parallelDir)

printToFileF(paste(c(objectsDir,'progress.txt'),collapse=''),
	     	 paste(c('done','\n'),collapse=''))
