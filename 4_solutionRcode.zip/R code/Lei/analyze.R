setwd("/Users/yangleicq/Documents/2014 Fall/stat 675/homework 4")

load_mnist()
need <- train$y==4|train$y==9
trainy49 <- train$y[need]
trainy49[trainy49==4] <- 0
trainy49[trainy49==9] <- 1

trainx49 <- train$x[need,]

need <- test$y==4|test$y==9
testy49 <- test$y[need]
testx49 <- test$x[need,]
testy49[testy49==4] <- 0
testy49[testy49==9] <- 1


rm(test)
rm(train)
rm(need)


good <- which(apply(trainx49,2,sum)!=0)

trainx49 <-trainx49[,good]
testx49<- testx49[,good]







re_log_1<-logitboost(trainx49,trainy49,linearforward,1,50)
re_log_10<-logitboost(trainx49,trainy49,linearforward,10,50)

save(re_log_1,file="logit1_50.RData")
save(re_log_10,file="logit10_50.RData")

load("logit1_50.RData")
load("logit10_50.RData")
log1_train_err<-testall(trainx49,trainy49,re_log_1,50,test_log1)
log1_test_err<-testall(testx49,testy49,re_log_1,50,test_log1)

log10_train_err<-testall(trainx49,trainy49,re_log_10,50,test_log10)
log10_test_err<-testall(testx49,testy49,re_log_10,50,test_log10)

save(log1_train_err,log1_test_err,log10_train_err,log10_test_err,file="logitlinear")




re_1<-adaboost(trainx49,trainy49,logit1,50)

re_10<-adaboost(trainx49,trainy49,logit10,50)

save(re_10,file="adalogit10_50.RData")
save(re_1,file="adalogit1_50.RData")

load("adalogit1_50.RData")
load("adalogit10_50.RData")



test1(testx49,testy49,re_1,50)
test10(testx49,testy49,re_10,50)

train.er1 <-testall(trainx49,trainy49,re_1,50,test1)
test.er1 <-testall(testx49,testy49,re_1,50,test1)
train.er10 <-testall(trainx49,trainy49,re_10,50,test10)
test.er10 <-testall(testx49,testy49,re_10,50,test10)

save(train.er1,test.er1,train.er10,test.er10,file="adalogit")




