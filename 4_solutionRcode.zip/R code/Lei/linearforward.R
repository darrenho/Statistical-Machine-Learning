library(leaps)

linearforward<-function(x,z,w,n){
  re<-regsubsets(x=x,y=z,weights=w,nbest=1,nvmax=n-1,method="forward")    
  ind <- summary(re)$which
  ind0<- ind[n,]
  as.numeric(colnames(ind)[ind0][-1]) 
}



