

adaboost <- function(x,y,base,M,w=rep(1,length(y))){ 
mod <- list()
betaM <- numeric(M)
for (m in 1:M)
{ cat(m)
  g <- base(x,y,w)
  model <- glm(y~x[,g],family=binomial(),weights=w)
  mod[[m]] <- c(coefficients(model))
  names(mod[[m]])<-c(0,g)
  pred0 <- as.numeric(predict(model,type="response")>0.5)
  pred <- as.numeric(pred0!=y)
  R <- sum(w*(pred))/sum(w)
  beta <- log((1-R)/R)
  betaM[m] <- beta
  w <- w*exp(beta*pred)
  
}
list(mod,betaM,w)
}

adacon<-function(x,y,base,M,adaobj){
  re <- adaboost(x,y,base,M,w=adaobj[[3]])
  list(append(adaobj[[1]],re[[1]]),c(adaobj[[2]],re[[2]]),re[[3]])
}

library(boot)

test1<-function(x,y,re,M) {
  pred <- numeric(length(y))
  beta <- re[[2]]
  for(m in 1:M)
  {
    coe<-re[[1]][[m]]
    num<-as.numeric(names(coe)[-1])  
    pred0 <-as.numeric(inv.logit(x[,num]*coe[-1]+coe[1])>0.5)*2-1
    pred <- pred+pred0*beta[m]
  }
  
  pre<- as.numeric(pred>0)
  sum(as.numeric(pre!=y))/length(y)
}


test10<-function(x,y,re,M) {
  pred <- numeric(length(y))
  beta <- re[[2]]
  for(m in 1:M)
  {
    coe<-re[[1]][[m]]
    num<-as.numeric(names(coe)[-1])  
    pred0 <-as.numeric(inv.logit(x[,num]%*%coe[-1]+coe[1])>0.5)*2-1
    pred <- pred+pred0*beta[m]
  }
  
  pre<- as.numeric(pred>0)
  sum(as.numeric(pre!=y))/length(y)
}

testall<- function(x,y,re,M,test){
  err<-numeric(M)
  for(i in 1:M)
    err[i] <- test(x,y,re,i)
  err
}