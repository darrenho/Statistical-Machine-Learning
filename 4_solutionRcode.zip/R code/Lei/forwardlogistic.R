logit1 <- function(x,y,w)
     { 
       N <- dim(x)[2]
       n <- 0
       for(i in 1:N)
           { model <- glm(y~x[,i],family=binomial(),weights=w)
             a <- extractAIC(model)[2]
             if(i==1) aicr <- a
             if(a < aicr)
                  {aicr <- a
                   n <-i
                  }
           }
        n
      }

logita <- function(x,y,ind0,w)
      { aicr <- 20000
        N <- dim(x)[2]
        n<-0
        for(i in 1:N)
              { model <- glm(y~x[,c(ind0,i)],family=binomial(),weights=w)
                a <- extractAIC(model)[2]
                if(i==1) aicr <- a
                if(a < aicr)
                  {aicr <- a
                   n <-i
                  }
              }
        c(ind0,n)
       }

logit10 <- function(x,y,w)
{ for(i in 1:10){
  if(i==1) 
  re<-logit1(x,y,w) else
     re<-logita(x,y,re,w)
}
re
}


