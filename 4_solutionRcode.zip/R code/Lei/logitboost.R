
logitboost <- function(x,y,base,n,M){ 
  mod <- list()
  len<-length(y)
  ####initialize values
  p<-rep(1/2,len)
  Fx<-rep(0,len)

  for (m in 1:M)
  { cat(m)
    ####compute weights w and working response z
    w<-p*(1-p)
    ##safeproof of NA values
    w[w<0.00001]<-0.00001
    w[is.na(w)]<-0.00001
    z<-(y-p)/w
    ####base function return the index of variables it selected.
    ####Here base=linearforward
    g <- base(x,z,w,n)
    ####record each model
    model <- lm(z~x[,g],weights=w)
    mod[[m]] <- c(coefficients(model))
    names(mod[[m]])<-c(0,g)
    ####fitted value of each model
    fx <- predict(model)
    ####update Fx and p
    Fx<-Fx+1/2*fx
    p<-1/(1+exp(-2*Fx))

  }
  mod
}

library(leaps)

linearforward<-function(x,z,w,n){
  re<-regsubsets(x=x,y=z,weights=w,nbest=1,nvmax=n-1,method="forward")    
  ind <- summary(re)$which
  ind0<- ind[n,]
  as.numeric(colnames(ind)[ind0][-1]) 
}


####functions to compute error rate

test_log1<-function(x,y,re,M) {
  pred <- numeric(length(y))
  for(m in 1:M)
  {
    coe<-re[[m]]
    num<-as.numeric(names(coe)[-1])  
    pred0 <-x[,num]*coe[-1]+coe[1]
    pred <- pred+pred0
  }
  
  pre<- as.numeric(pred>0)
  sum(as.numeric(pre!=y))/length(y)
}


test_log10<-function(x,y,re,M) {
  pred <- numeric(length(y))
  for(m in 1:M)
  {
    coe<-re[[m]]
    num<-as.numeric(names(coe)[-1])  
    pred0 <-x[,num]%*%coe[-1]+coe[1]
    pred <- pred+pred0
  }
  
  pre<- as.numeric(pred>0)
  sum(as.numeric(pre!=y))/length(y)
}


