######################################
load packages and data
######################################
install.packages("darch")
install.packages("e1071")
install.packages("xtable", type="source")
library(xtable)
library(darch)
library(e1071)
library(MASS)
library(fields)
library(glmnet)
setwd("C:/Users/benjamin/Desktop/Fall 2014/Stat 675/hw4/")
readMNIST("C:/Users/benjamin/Desktop/Fall 2014/Stat 675/hw4/")
load("train.Rdata")
load("test.Rdata")


##create list of training data###
fours.or.nines.indeces=which(trainLabels[,5]==1|trainLabels[,10]==1)
fours.or.nines.indeces

trains=list()
for(i in fours.or.nines.indeces){
  trains[[length(trains)+1]]=list()
  trains[[length(trains)]][[1]]=i
  trains[[length(trains)]][[2]]=matrix(as.vector(trainData[i,]), nrow=28, ncol=28)
  if(trainLabels[i,5]==1){ 
    trains[[length(trains)]][[3]]=4
  }
  if(trainLabels[i,10]==1){
    trains[[length(trains)]][[3]]=9
  }  
  names(trains[[length(trains)]])=c("index", "image", "label")
    
  }


###matrix of training data####

X=matrix(nrow=length(trains), ncol=28^2)
Y=NULL
for(i in 1:length(trains)){
  X[i,]=as.vector(trains[[i]]$image)
  Y[i]=(trains[[i]]$label==9)
}


##list of test data
fours.or.nines.indeces.tests=which(testLabels[,5]==1|testLabels[,10]==1)


tests=list()
for(i in fours.or.nines.indeces.tests){
  tests[[length(tests)+1]]=list()
  tests[[length(tests)]][[1]]=i
  tests[[length(tests)]][[2]]=matrix(as.vector(testData[i,]), nrow=28, ncol=28)
  if(testLabels[i,5]==1){ 
    tests[[length(tests)]][[3]]=4
  }
  if(testLabels[i,10]==1){
    tests[[length(tests)]][[3]]=9
  }  
  names(tests[[length(tests)]])=c("index", "image", "label")
  
}



X.test=matrix(nrow=length(tests), ncol=28^2)
Y.test=NULL
for(i in 1:length(tests)){
  X.test[i,]=as.vector(tests[[i]]$image)
  Y.test[i]=(tests[[i]]$label==9)
}





###select best "num.vars" variables based on AIC###
pick.covariates=function(Y,X,num.vars=1, weights=NULL){
  n=length(Y)
  min.locs=NULL
  for(j in 1:num.vars){
    if(j==1){
      min.aic=glm(Y~1, family="binomial", weights=weights*length(Y)/sum(weights))$aic
    }else{
      min.aic=glm(Y~X[,c(min.locs)], family="binomial", weights=weights*length(Y)/sum(weights))$aic
    }
    temp.loc=1  
    for(i in 2:28^2){
      aic=glm(Y~X[,c(min.locs,i)], family="binomial", weights=weights*length(Y)/sum(weights))$aic
      if(aic<min.aic){
        temp.loc=i
        min.aic=aic
      }
    }
    min.locs[length(min.locs)+1]=temp.loc}
  return(min.locs)}





###ADA boost with logistic regression and 1 covariate###
num.vars=1
M=50
n=length(Y)
w=matrix(nrow=M, ncol=n)
w[1,]=(1/n)*rep(1,n)
covs=matrix(nrow=M, ncol=num.vars)
covs[1,]=pick.covariates(Y,X,num.vars=num.vars,weights=w[1,])
#mod=glm(Y~X[,covs[1,]], weights=w[1,]*length(Y)/sum(w[1,]), family="binomial")
model=list()
model[[1]]=glm(Y~X[,covs[1,]], weights=w[1,]*length(Y)/sum(w[1,]), family="binomial")
beta=NULL
R=NULL
probs=model[[1]]$fitted.values
g=matrix(nrow=M, ncol=n)
g[1,]= probs>.5
miss.class=g[1,]!=Y
R[1]=sum(w[1,]*miss.class)/sum(w[1,])
beta[1]=log((1-R[1])/R[1])
for(m in 2:M){
  for(i in 1:n){
    w[m,i]=w[m-1,i]*exp(beta[m-1]*miss.class[i])
  }
  
  covs[m,]=pick.covariates(Y,X,num.vars=1,weights=w[m,])
  model[[m]]=glm(Y~X[,covs[m,]], weights=w[m,]*length(Y)/sum(w[m,]), family="binomial")
  probs=model[[m]]$fitted.values
  g[m,]= probs>.5
  miss.class=g[m,]!=Y
  R[m]=sum(w[m,]*miss.class)/sum(w[m,])
  beta[m]=log((1-R[m])/R[m])
  
}


g.alt=g+(-1)*(g==FALSE)


output=matrix(nrow=M,ncol=length(Y))
for(iters in 1:M){
  output[iters,]=t(beta[1:iters])%*%g.alt[1:iters,]>0
}

train.error=NULL
for( i in 1:M){
  train.error[i]=sum(output[i,]!=Y)/length(Y)
  print(train.error[i])
}

g.test=matrix(ncol=length(Y.test), nrow=M)
for(m in 1:M){
logit=cbind(rep(1,length(Y.test)), X.test[, covs[m,]])%*%coefficients(model[[m]])
test.probs=inv.logit(logit)
g.test[m,]=(test.probs>.5)-1*(test.probs<.5)
}


output.test=matrix(nrow=M,ncol=length(Y.test))
for(iters in 1:M){
  output.test[iters,]=t(beta[1:iters])%*%g.test[1:iters,]>0
}

test.error=NULL
for( i in 1:M){
  test.error[i]=sum(output.test[i,]!=Y.test)/length(Y.test)
  print(test.error[i])
}



##create plot (saved to pdf) of training error and test error###
pdf("Logreg_1cov.pdf")
M=50
par(mfrow=c(1,1))
plot(1:M, train.error[1:M], col="red", cex=0, xlim=c(0,M+2), ylim=c(0,.2), 
     main="Logistic Reg. (Single Covariate) ADAboost", ylab="error",
     xlab="# Boosting Iterations")
lines(1:M, train.error[1:M], col="red", pch=".")
lines(1:M, test.error[1:M], col="blue")
legend(15,.17, c("train error", "test error"), col=c("red","blue"), lty=c(1,1))
dev.off()










####Ada boost with logistic regression and 10 covariates####
num.vars=10
M=50
n=length(Y)
w=matrix(nrow=M, ncol=n)
w[1,]=(1/n)*rep(1,n)
covs=matrix(nrow=M, ncol=num.vars)
covs[1,]=pick.covariates(Y,X,num.vars=num.vars,weights=w[1,])
#mod=glm(Y~X[,covs[1,]], weights=w[1,]*length(Y)/sum(w[1,]), family="binomial")
model=list()
model[[1]]=glm(Y~X[,covs[1,]], weights=w[1,]*length(Y)/sum(w[1,]), family="binomial")
beta=NULL
R=NULL
probs=model[[1]]$fitted.values
g=matrix(nrow=M, ncol=n)
g[1,]= probs>.5
miss.class=g[1,]!=Y
R[1]=sum(w[1,]*miss.class)/sum(w[1,])
beta[1]=log((1-R[1])/R[1])
for(m in 2:M){
  for(i in 1:n){
    w[m,i]=w[m-1,i]*exp(beta[m-1]*miss.class[i])
  }
  
  covs[m,]=pick.covariates(Y,X,num.vars=num.vars,weights=w[m,])
  model[[m]]=glm(Y~X[,covs[m,]], weights=w[m,]*length(Y)/sum(w[m,]), family="binomial")
  probs=model[[m]]$fitted.values
  g[m,]= probs>.5
  miss.class=g[m,]!=Y
  R[m]=sum(w[m,]*miss.class)/sum(w[m,])
  beta[m]=log((1-R[m])/R[m])
  
}

g.alt=g+(-1)*(g==FALSE)


output=matrix(nrow=M,ncol=length(Y))
for(iters in 1:M){
  output[iters,]=t(beta[1:iters])%*%g.alt[1:iters,]>0
}

train.error=NULL
for( i in 1:M){
  train.error[i]=sum(output[i,]!=Y)/length(Y)
  print(train.error[i])
}


g.test=matrix(ncol=length(Y.test), nrow=M)
for(m in 1:M){
  logit=cbind(rep(1,length(Y.test)), X.test[, covs[m,]])%*%coefficients(model[[m]])
  test.probs=inv.logit(logit)
  g.test[m,]=(test.probs>.5)-1*(test.probs<.5)
}


output.test=matrix(nrow=M,ncol=length(Y.test))
for(iters in 1:M){
  output.test[iters,]=t(beta[1:iters])%*%g.test[1:iters,]>0
}

test.error=NULL
for( i in 1:M){
  test.error[i]=sum(output.test[i,]!=Y.test)/length(Y.test)
  print(test.error[i])
}


##create plot (saved to pdf) of training error and test error###
pdf("Logreg_10cov.pdf")
M=50
par(mfrow=c(1,1))
plot(1:M, train.error, col="red", cex=0, xlim=c(0,50+2), ylim=c(0,.2), 
     main="Logistic Reg. (10 Covariates) ADAboost", ylab="error",
     xlab="# Boosting Iterations")
lines(1:M, train.error, col="red", pch=".")
lines(1:M, test.error, col="blue")
legend(15,.15, c("train error", "test error"), col=c("red","blue"), lty=c(1,1))
dev.off()










