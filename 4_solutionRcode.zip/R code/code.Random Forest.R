
# load digits data as before

library(bigrf)
library(doParallel)
registerDoParallel(cores=detectCores(all.tests=TRUE))

## m = 5 ##

forest.5 = bigrfc(x = as.data.frame(train.x2), y = as.factor(train.y), 
                  ntrees = 100L, nsplitvar = 5L)
trainerr.5 = forest.5@trainerr
plot(trainerr.5, type="l")

mypred.5 = predict(forest.5, as.data.frame(test.x2), as.factor(test.y),
                   printerrfreq=1L)
table(mypred.5, as.factor(test.y))

## m = 10 ##

forest.10 = bigrfc(x = as.data.frame(train.x2), y = as.factor(train.y),
                   ntrees = 100L, nsplitvar = 10L)

trainerr.10 = forest.10@trainerr
lines(trainerr.10, type="l", col="purple")

mypred.10 = predict(forest.10, as.data.frame(test.x2), as.factor(test.y),
                    printerrfreq=1L)
table(mypred.10, as.factor(test.y))

## m = 25 ##

forest.25 = bigrfc(x = as.data.frame(train.x2), y = as.factor(train.y),
                   ntrees = 100L, nsplitvar = 25L)

trainerr.25 = forest.25@trainerr
lines(trainerr.25, type="l", col="magenta")

mypred.25 = predict(forest.25, as.data.frame(test.x2), as.factor(test.y),
                    printerrfreq=1L)
table(mypred.25, as.factor(test.y))

## m = 50 ##

forest.50 = bigrfc(x = as.data.frame(train.x2), y = as.factor(train.y),
                   ntrees = 100L, nsplitvar = 50L)

trainerr.50 = forest.50@trainerr
lines(trainerr.50, type="l", col="orange")

mypred.50 = predict(forest.50, as.data.frame(test.x2), as.factor(test.y),
                    printerrfreq=1L)
table(mypred.50, as.factor(test.y))

## m = 100 ##

forest.100 = bigrfc(x = as.data.frame(train.x2), y = as.factor(train.y),
                    ntrees = 100L, nsplitvar = 100L)

trainerr.100 = forest.100@trainerr
lines(trainerr.100, type="l", col="red")

mypred.100 = predict(forest.100, as.data.frame(test.x2), as.factor(test.y),
                     printerrfreq=1L)
table(mypred.100, as.factor(test.y))

## m = 200 ##

forest.200 = bigrfc(x = as.data.frame(train.x2), y = as.factor(train.y),
                    ntrees = 100L, nsplitvar = 200L)

trainerr.200 = forest.200@trainerr
lines(trainerr.200, type="l", col="blue")

mypred.200 = predict(forest.200, as.data.frame(test.x2), as.factor(test.y),
                     printerrfreq=1L)
table(mypred.200, as.factor(test.y))

## m = 400 ##

forest.400 = bigrfc(x = as.data.frame(train.x2), y = as.factor(train.y),
                    ntrees = 100L, nsplitvar = 400L)

trainerr.400 = forest.400@trainerr
lines(trainerr.400, type="l", col="green")

mypred.400 = predict(forest.400, as.data.frame(test.x2), as.factor(test.y),
                     printerrfreq=1L)
table(mypred.400, as.factor(test.y))

## m = 600 ##

forest.600 = bigrfc(x = as.data.frame(train.x2), y = as.factor(train.y),
                    ntrees = 100L, nsplitvar = 600L)

trainerr.600 = forest.600@trainerr
lines(trainerr.600, type="l", col="cyan")

mypred.600 = predict(forest.600, as.data.frame(test.x2), as.factor(test.y),
                     printerrfreq=1L)
table(mypred.600, as.factor(test.y))

