library(rpart)
library(ada)

#-------------------------#
# Load train & test sets  #
#-------------------------#

source("loaddata.R")

load_mnist()
show_digit(train$x[4220,])
train$y[4220]

ls(train); ls(test)
dim(train$x);dim(test$x)

#-------------------------#
# Find the 4's and 9's    #
#-------------------------#

itrain.49 = which(train$y==4| train$y==9)
train.x = train$x[itrain.49,] 
train.y = train$y[itrain.49]

itest.49 = which(test$y==4| test$y==9)
test.x = test$x[itest.49,]
test.y = test$y[itest.49]

#-------------------------#
# Do some digging         #
#-------------------------#

n.unique.x = apply(train.x,2, function(x){length(unique(x))})
iuseful = which(n.unique.x>1)
train.x2 = train.x[,iuseful] #cuts down the number of predictors
test.x2 = test.x[,iuseful]

dim(train.x2)
dim(test.x2)

#-------------------------#
# Adaboost with trees     #
#-------------------------#

## stumps ##

stump = rpart.control(cp=-1, maxdepth=1, minsplit=0)
# Also ran 100 iterations just to see
# No evidence of overfitting so keeping the 50 iteration one
g1 = ada(x=train.x2, y=train.y, test.x=test.x2, test.y=test.y, control=stump)

## AdaBoost with 10-depth trees ##

ten = rpart.control(cp=-1, maxdepth=10, minsplit=0)
system.time(ada(x=train.x2, y=train.y, control=ten, iter=1))

g10 = ada(x=train.x2, y=train.y, test.x=test.x2, test.y=test.y, control=ten)

#------------------------------------------------#
# Adaboost with trees and logistic loss function #
# (i.e. "Logitboost")                            #
#------------------------------------------------#

## stump ##

stump = rpart.control(cp=-1, maxdepth=1, minsplit=0)
logit1 = ada(x=train.x2, y=train.y, test.x=test.x2, test.y=test.y, 
             loss="logistic",control=stump)

## 10-depth tree ##

ten = rpart.control(cp=-1, maxdepth=10, minsplit=0)
logit10 = ada(x=train.x2, y=train.y, test.x=test.x2, test.y=test.y, 
              loss="logistic",control=ten)

#----------------------------------------#
# Saving the training and test errors    #
#----------------------------------------#

adatree.df = as.data.frame(
  cbind(g1$model$errs[,c(1,3)],
        g10$model$errs[,c(1,3)],
        logit1$model$errs[,c(1,3)],
        logit10$model$errs[,c(1,3)]))
names(adatree.df) = c("train.adastump", "test.adastump",
                      "train.ada10","test.ada10",
                      "train.logitstump", "test.logitstump",
                      "train.logit10", "test.logit10")

save(adatree.df, file="basetrees.Rdata")



